This Android application started as BluIno from http://itmexicali.webs.com/ 
and has been modified for use as a remote control for the rPi-Arduino gauges.

BluIno source is available from gitHub: https://github.com/MiichaelD/BluIno

