package com.esi.gauges;

import com.esi.gauges.R;

import android.app.Activity;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * This is the main Activity that displays the current chat session.
 */
public class Main extends Activity {
    // Debugging
    public static final String TAG = "Gauges";
    public static final boolean D = true;
    
    
    public SharedPreferences settings;// To save preferences accesible by other Apps, just 
    public SharedPreferences.Editor settingsEditor;
    
    public static int currentContentView=0;

    // Message types sent from the BlueInterfaceService Handler
    public static final int MESSAGE_STATE_CHANGE = 1, MESSAGE_READ = 2, MESSAGE_WRITE = 3, MESSAGE_DEVICE_NAME = 4, MESSAGE_TOAST = 5, SYNC_CONNECTION = 6,
    // Intent request codes
    						REQUEST_CONNECT_DEVICE = 1, REQUEST_ENABLE_BT = 2;
    
    // Key names received from the BlueInterfaceService Handler
    public static final String DEVICE_NAME = "device_name", TOAST = "toast";
    
    // Layout Views
    @SuppressWarnings("unused")
    private TextView mTitle;
    private EditText mOutEditText;

    // Name of the connected device
    private String mConnectedDeviceName = null;
    
    // String buffer for outgoing messages
    private StringBuffer mOutStringBuffer;
    
    // Local Bluetooth adapter
    private BluetoothAdapter mBluetoothAdapter = null;
    
    private ImageButton buttonUp;
    private ImageButton buttonDown;
    private ImageButton buttonLeft;
    private ImageButton buttonRight;
    private ImageButton buttonMenu;
    private ImageButton buttonSelect;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(D) Log.e(TAG, "+++ ON CREATE +++");
        
        // Set up the window layout
        requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
        //setContentView((PView=new PadView(this,mHandler)));
        setContentView(R.layout.custom_title);
        
        //getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE, R.layout.custom_title);

        //get the preferences saved on the file named as TAG
        settings = getSharedPreferences(TAG, 0);					//to read
        settingsEditor = settings.edit();	//to write
        
        
        // Set up the custom title
        mTitle = (TextView) findViewById(R.id.title_left_text);
        mTitle.setText(R.string.app_name);
        mTitle = (TextView) findViewById(R.id.title_right_text);
               
        addListenerOnButton();
                
        // Get local Bluetooth adapter
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        // If the adapter is null, then Bluetooth is not supported
        if (mBluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth is not available", Toast.LENGTH_LONG).show();
            finish();
        }
        
        
    	
    }

    public void addListenerOnButton() {
	 
	        //Select a specific button to bundle it with the action you want
	        buttonUp = (ImageButton) findViewById(R.id.imageButtonUp);
	        //button2.setBackgroundDrawable(null);
	        buttonUp.setBackgroundColor(0x0106000d);
	        
	        buttonUp.setOnClickListener(new OnClickListener() {
	 
	            @Override
	            public void onClick(View view) {
	            	 	 
                    BluetoothService.mBlueService.write(("bu").getBytes());
	            }
	 
	        });
	        
	        buttonUp.setOnTouchListener(new OnTouchListener() {
	            @Override
	            public boolean onTouch(View v, MotionEvent event) {
	                if(event.getAction() == MotionEvent.ACTION_UP) {
	                	buttonUp.setImageResource(R.drawable.up_arrow);    
	                } else if (event.getAction() == MotionEvent.ACTION_DOWN) {
	                	buttonUp.setImageResource(R.drawable.up_arrow_pressed);
	                }
					return false;
	            }
	        });	        
	        
	        buttonDown = (ImageButton) findViewById(R.id.imageButtonDown);
	        //button2.setBackgroundDrawable(null);
	        buttonDown.setBackgroundColor(0x0106000d);
	        
	        buttonDown.setOnClickListener(new OnClickListener() {
	 
	            @Override
	            public void onClick(View view) {
	            	 	 
                    BluetoothService.mBlueService.write(("bd").getBytes());
	            }
	 
	        });
	        
	        buttonDown.setOnTouchListener(new OnTouchListener() {
	            @Override
	            public boolean onTouch(View v, MotionEvent event) {
	                if(event.getAction() == MotionEvent.ACTION_UP) {
	                	buttonDown.setImageResource(R.drawable.down_arrow);    
	                } else if (event.getAction() == MotionEvent.ACTION_DOWN) {
	                	buttonDown.setImageResource(R.drawable.down_arrow_pressed);
	                }
					return false;
	            }
	        });	  
	        
	        buttonLeft = (ImageButton) findViewById(R.id.imageButtonLeft);
	        //button2.setBackgroundDrawable(null);
	        buttonLeft.setBackgroundColor(0x0106000d);
	        
	        buttonLeft.setOnClickListener(new OnClickListener() {
	 
	            @Override
	            public void onClick(View view) {
	            	 	 
                    BluetoothService.mBlueService.write(("bl").getBytes());
	            }
	 
	        });
	        
	        buttonLeft.setOnTouchListener(new OnTouchListener() {
	            @Override
	            public boolean onTouch(View v, MotionEvent event) {
	                if(event.getAction() == MotionEvent.ACTION_UP) {
	                	buttonLeft.setImageResource(R.drawable.left_arrow);    
	                } else if (event.getAction() == MotionEvent.ACTION_DOWN) {
	                	buttonLeft.setImageResource(R.drawable.left_arrow_pressed);
	                }
					return false;
	            }
	        });	        
	        	
	        buttonRight = (ImageButton) findViewById(R.id.imageButtonRight);
	        //button2.setBackgroundDrawable(null);
	        buttonRight.setBackgroundColor(0x0106000d);
	        
	        buttonRight.setOnClickListener(new OnClickListener() {
	 
	            @Override
	            public void onClick(View view) {
	            	 	 
                    BluetoothService.mBlueService.write(("br").getBytes());
	            }
	 
	        });
	        
	        buttonRight.setOnTouchListener(new OnTouchListener() {
	            @Override
	            public boolean onTouch(View v, MotionEvent event) {
	                if(event.getAction() == MotionEvent.ACTION_UP) {
	                	buttonRight.setImageResource(R.drawable.right_arrow);    
	                } else if (event.getAction() == MotionEvent.ACTION_DOWN) {
	                	buttonRight.setImageResource(R.drawable.right_arrow_pressed);
	                }
					return false;
	            }
	        });	        
	     
	        buttonMenu = (ImageButton) findViewById(R.id.imageButtonMenu);
	        //button2.setBackgroundDrawable(null);
	        buttonMenu.setBackgroundColor(0x0106000d);
	        
	        buttonMenu.setOnClickListener(new OnClickListener() {
	 
	            @Override
	            public void onClick(View view) {
	            	 	 
                    BluetoothService.mBlueService.write(("bm").getBytes());
	            }
	 
	        });
	        
	        buttonMenu.setOnTouchListener(new OnTouchListener() {
	            @Override
	            public boolean onTouch(View v, MotionEvent event) {
	                if(event.getAction() == MotionEvent.ACTION_UP) {
	                	buttonMenu.setImageResource(R.drawable.menu);    
	                } else if (event.getAction() == MotionEvent.ACTION_DOWN) {
	                	buttonMenu.setImageResource(R.drawable.menu_pressed);
	                }
					return false;
	            }
	        });	   
	        
	        buttonSelect = (ImageButton) findViewById(R.id.imageButtonSelect);
	        //button2.setBackgroundDrawable(null);
	        buttonSelect.setBackgroundColor(0x0106000d);
	        
	        buttonSelect.setOnClickListener(new OnClickListener() {
	 
	            @Override
	            public void onClick(View view) {
	            	 	 
                    BluetoothService.mBlueService.write(("bs").getBytes());
	            }
	 
	        });
	        
	        buttonSelect.setOnTouchListener(new OnTouchListener() {
	            @Override
	            public boolean onTouch(View v, MotionEvent event) {
	                if(event.getAction() == MotionEvent.ACTION_UP) {
	                	buttonSelect.setImageResource(R.drawable.select);    
	                } else if (event.getAction() == MotionEvent.ACTION_DOWN) {
	                	buttonSelect.setImageResource(R.drawable.select_pressed);
	                }
					return false;
	            }
	        });	
	    }
    
    @Override
    public void onStart() {
        super.onStart();
        if(D) Log.e(TAG, "++ ON START ++");

        // If BT is not on, request that it be enabled.
        // setupChat() will then be called during onActivityResult
        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
        // Otherwise, setup the chat session
        } else {
            if (BluetoothService.mBlueService == null) setupChat();
        }
        
    }

    @Override
    public synchronized void onResume() {
        super.onResume();
        if(D) Log.e(TAG, "+ ON RESUME +");

        // Performing this check in onResume() covers the case in which BT was
        // not enabled during onStart(), so we were paused to enable it...
        // onResume() will be called when ACTION_REQUEST_ENABLE activity returns.
        if (BluetoothService.mBlueService != null) {
            // Only if the state is STATE_NONE, do we know that we haven't started already
            if (BluetoothService.mBlueService.getState() == BluetoothService.STATE_NONE) {
              // Start the Bluetooth chat services
              BluetoothService.mBlueService.start();
            }
        }
    }

    private void setupChat() {
        Log.d(TAG, "setupChat()");
        
        // Initialize the BlueInterfaceService to perform bluetooth connections
        BluetoothService.mBlueService = new BluetoothService(this, mHandler);

        // Initialize the buffer for outgoing messages
        mOutStringBuffer = new StringBuffer("");
    }

    @Override
    public synchronized void onPause() {
        super.onPause();
        if(D) Log.e(TAG, "- ON PAUSE -");
    }

    @Override
    public void onStop() {
        super.onStop();
        if(D) Log.e(TAG, "-- ON STOP --");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // Stop the Bluetooth chat services
        if (BluetoothService.mBlueService != null){
        	BluetoothService.mBlueService.stop();
        }
        if(D) Log.e(TAG, "--- ON DESTROY ---");
    }

    /**
     * Sends a message.
     * @param message  A string of text to send.
     */
    public void sendMessage(String message) {
        // Check that we're actually connected before trying anything
        if (BluetoothService.mBlueService.getState() != BluetoothService.STATE_CONNECTED) {
            Toast.makeText(this, R.string.not_connected, Toast.LENGTH_SHORT).show();
            return;
        }

        // Check that there's actually something to send
        if (message.length() > 0) {
            // Get the message bytes and tell the BlueInterfaceService to write
            byte[] send = message.getBytes();
            BluetoothService.mBlueService.write(send);
            if(D)
            	Log.d(TAG,"Message Sent: "+message);
            // Reset out string buffer to zero and clear the edit text field
            mOutStringBuffer.setLength(0);
            mOutEditText.setText(mOutStringBuffer);
        }
    }


    // The Handler that gets information back from the BlueInterfaceService
    private final Handler mHandler = new Handler() {    	
    @Override
    public void handleMessage(Message msg) {
            switch (msg.what) {
            case MESSAGE_STATE_CHANGE:
                if(D) Log.i(TAG, "MESSAGE_STATE_CHANGE: " + msg.arg1);
                switch (msg.arg1) {
                case BluetoothService.STATE_CONNECTED:
                    mTitle.setText(R.string.title_connected_to);
                    mTitle.append(mConnectedDeviceName);
                    //Let arduino Know the ratio we're going to use.
                    // jfs - this is how to send a message to arduino
                    //BluetoothService.mBlueService.write(('L'+PadView.intToString(Options.getInstance().getLBarValue())
                    //		+'R'+PadView.intToString(Options.getInstance().getLBarValue())).getBytes());
                    break;
                case BluetoothService.STATE_CONNECTING:
                    mTitle.setText(R.string.title_connecting);
                    break;
                case BluetoothService.STATE_LISTEN:
                case BluetoothService.STATE_NONE:
                    mTitle.setText(R.string.title_not_connected);
                    break;
                }
                break;
            case SYNC_CONNECTION:
            	if(D)
        			Log.i(TAG,"SYNCED Connection: "+msg.obj);
            	break;
            case MESSAGE_WRITE:
                //byte[] writeBuf = (byte[]) msg.obj;
                // construct a string from the buffer
               // String writeMessage = new String(writeBuf);
                try {
            		
            	}catch(NumberFormatException e) {}
                break;
            case MESSAGE_READ:
                byte[] readBuf = (byte[]) msg.obj;
                // construct a string from the valid bytes in the buffer
                if(msg.arg1>0) {
                	String readMessage = new String(readBuf, 0, msg.arg1);
                	try {
                		if(D)
                			Log.i(TAG,"RemoteMsg: \""+readMessage+"\"");
                	}catch(NumberFormatException e) {}//tv.setText(readMessage);}
                }
                break;
                
            case MESSAGE_DEVICE_NAME:
                // save the connected device's name
                mConnectedDeviceName = msg.getData().getString(DEVICE_NAME);
                Toast.makeText(getApplicationContext(), "Connected to " + mConnectedDeviceName, Toast.LENGTH_SHORT).show();
                break;
            case MESSAGE_TOAST:
                Toast.makeText(getApplicationContext(), msg.getData().getString(TOAST),Toast.LENGTH_SHORT).show();
                break;
            }
        }
    };


    
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(D) Log.d(TAG, "onActivityResult " + resultCode);
        switch (requestCode) {
        case REQUEST_CONNECT_DEVICE:
            // When DeviceListActivity returns with a device to connect
            if (resultCode == Activity.RESULT_OK) {
                // Get the device MAC address
                String address = data.getExtras().getString(DeviceListActivity.EXTRA_DEVICE_ADDRESS);
                // Get the BLuetoothDevice object
                BluetoothDevice device=null ;
                try{
                	device = mBluetoothAdapter.getRemoteDevice(address);
                // Attempt to connect to the device
                }catch(IllegalArgumentException e){ 
                	Log.e(TAG,"@Main-getRemoteDevice(address)",e);
                	Toast.makeText(getApplicationContext(), R.string.illegaldevice, Toast.LENGTH_SHORT).show();
                }
               
                if(device!=null)
                	BluetoothService.mBlueService.connect(device);
            }
            break;
        case REQUEST_ENABLE_BT:
            // When the request to enable Bluetooth returns
            if (resultCode == Activity.RESULT_OK) {
                // Bluetooth is now enabled, so set up a chat session
                setupChat();
            } else {
                // User did not enable Bluetooth or an error occured
                Log.d(TAG, "BT not enabled");
                Toast.makeText(this, R.string.bt_not_enabled_leaving, Toast.LENGTH_SHORT).show();
                //finish();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        //if(BluetoothService.mBlueService != null)
        	inflater.inflate(BluetoothService.mBlueService != null?R.menu.option_menu:R.menu.option_menu_offline, menu);
        //else
        	//inflater.inflate(R.menu.option_menu_offline, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
        case R.id.scan:
            // Launch the DeviceListActivity to see devices and do scan
            Intent serverIntent = new Intent(this, DeviceListActivity.class);
            startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE);
            return true;
//        case R.id.options:
        	//show options menu dialog
//        	try{
//        		((EditText)menu.findViewById(R.id.editText1)).setText(Integer.toString(Options.getInstance().getLBarValue()));
//                ((EditText)menu.findViewById(R.id.editText2)).setText(Integer.toString(Options.getInstance().getRBarValue()));
//                menu.show();
//        	}catch(Exception ex){if(D)Log.e(TAG,ex.getMessage());}
//        	return true;
        case R.id.exit:
        	finish();
        	return true;
        }
        return false;
    }

    /** Called Before onPause(). */
    public void onSaveInstanceState(Bundle savedInstanceState) {
    	super.onSaveInstanceState(savedInstanceState);
      	if(D){
    		Log.i(TAG,"**OnSaveInstanceState**");
    	}
    	  // Save UI state changes to the savedInstanceState.
    	  // This bundle will be passed to onCreate if the process is
    	  // killed and restarted.
    	  savedInstanceState.putBoolean("MyBoolean", true);
    	  savedInstanceState.putDouble("myDouble", 1.9);
    	  //savedInstanceState.putInt("timesClosed", ++i);
    	  savedInstanceState.putString("MyString", "Welcome back to Android");
    	  // etc.
    	}

    /** Called Before onResume */
    @SuppressWarnings("unused")
    public void onRestoreInstanceState(Bundle savedInstanceState) {
    	  super.onRestoreInstanceState(savedInstanceState);
    	  if(D){
      		Log.i(TAG,"*OnRestoreInstanceState*");
      	}
    	  // Restore UI state from the savedInstanceState.
    	  // This bundle has also been passed to onCreate.
    	  boolean myBoolean = savedInstanceState.getBoolean("MyBoolean");
    	  double myDouble = savedInstanceState.getDouble("myDouble");
    	  //i = savedInstanceState.getInt("timesClosed");
    	  String myString = savedInstanceState.getString("MyString");
    	}

    
}