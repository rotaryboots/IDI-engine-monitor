/** Automatically generated file. DO NOT MODIFY */
package com.esi.gauges;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}