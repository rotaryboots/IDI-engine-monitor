#By J.Shuhy
#www.Shuhy.com

#The MIT License (MIT)
#
#Copyright (c) 2014 J.Shuhy
#
#Permission is hereby granted, free of charge, to any person obtaining a copy
#of this software and associated documentation files (the "Software"), to deal
#in the Software without restriction, including without limitation the rights
#to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#copies of the Software, and to permit persons to whom the Software is
#furnished to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in
#all copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
#THE SOFTWARE.

#Import libraries 
import math,random,sys,logging,serial,time,os,fcntl,pygame,settings


class RingBuffer:
   def __init__(self, size):
      self.data = [None for i in xrange(size)]
      self.size = size

   def append(self, x):
      self.data.pop(0)
      self.data.append(x)

   def get(self):
      return self.data

   def min(self):
      return min(self.data)

   def max(self):
      return max(self.data)

   def last(self):
      return self.data[self.size-1]

class Dataset(RingBuffer):
   def __init__(self,buffSize):
      RingBuffer.__init__(self,buffSize)
      self.initArrayRequired = True

      self.redLow = 0
      self.redHigh = 0
      self.yellowLow = 0
      self.yellowHigh = 0

   def setRed(self,low,high):
      self.redLow = low
      self.redHigh = high

   def setYellow(self,low,high):
      self.yellowLow = low
      self.yellowHigh = high

   def getColor(self, value):
      if value >= self.redHigh:
         return settings.RED
      elif value >= self.yellowHigh:
         return settings.YELLOW
      elif value >= self.yellowLow:
         return settings.GREEN
      elif value >= self.redLow:
         return settings.YELLOW
      else:
         return settings.RED
      
   def update(self,value):
      self.append(value)
      
      # initialize list with first value (average isn't ever used, just max & min)
      if self.initArrayRequired:
         self.initArrayRequired = False
         while self.min() == None:
            self.append(value)            
      
class Graph():
   def __init__(self,screen,dataset):
      self.screen = screen
      self.dataset = dataset
      self.font = pygame.font.Font("DS-DIGI.TTF",30)

   def setLocation(self,x,y,width,height=0):
      self.x = x 
      self.y = y
      self.maxX = x + width
      
      if height == 0:
         self.height = screen.get_height() - (self.y*2)
      else:
         self.height = height        

   # setLocation must be called first
   def setScale(self,minVal,maxVal,midVal):
      self.minVal = minVal
      self.maxVal = maxVal

      self.yRes = self.height / (maxVal - minVal)

      text = self.font.render("{:.1f}".format(maxVal),True,(0,0,0))
      #text = self.font.render(str(maxVal),True,(0,0,0))
      self.valueWidth = text.get_width() + 10 

      self.midVal = midVal
      
   def render(self):
      # pixels for number scale
      lineX = self.x + self.valueWidth

      lineY = (self.maxVal - self.dataset.redHigh) * self.yRes + self.y
      text = self.font.render("{:.1f}".format(self.dataset.redHigh),True,settings.RED)
      #text = self.font.render(str(self.dataset.redHigh),True,settings.RED)
      self.screen.blit(text,(self.x,lineY-15))
      pygame.draw.line(screen,settings.RED,(lineX,lineY),(self.maxX,lineY))

      lineY = (self.maxVal - self.dataset.redLow) * self.yRes + self.y
      text = self.font.render("{:.1f}".format(self.dataset.redLow),True,settings.RED)
      #text = self.font.render(str(self.dataset.redLow),True,settings.RED)
      self.screen.blit(text,(self.x,lineY-15))
      pygame.draw.line(screen,settings.RED,(lineX,lineY),(self.maxX,lineY))

      lineY = (self.maxVal - self.dataset.yellowHigh) * self.yRes + self.y
      text = self.font.render("{:.1f}".format(self.dataset.yellowHigh),True,settings.YELLOW)
      #text = self.font.render(str(self.dataset.yellowHigh),True,settings.YELLOW)
      self.screen.blit(text,(self.x,lineY-15))
      pygame.draw.line(screen,settings.YELLOW,(lineX,lineY),(self.maxX,lineY))

      lineY = (self.maxVal - self.dataset.yellowLow) * self.yRes + self.y
      text = self.font.render("{:.1f}".format(self.dataset.yellowLow),True,settings.YELLOW)
      #text = self.font.render(str(self.dataset.yellowLow),True,settings.YELLOW)
      self.screen.blit(text,(self.x,lineY-15))
      pygame.draw.line(screen,settings.YELLOW,(lineX,lineY),(self.maxX,lineY))

      #midpoint = (self.dataset.yellowHigh + self.dataset.yellowLow) / 2
      lineY = (self.maxVal - self.midVal) * self.yRes + self.y
      text = self.font.render("{:.1f}".format(self.midVal),True,settings.GREEN)
      #text = self.font.render(str(self.midVal),True,settings.GREEN)
      self.screen.blit(text,(self.x,lineY-15))
      pygame.draw.line(screen,settings.GREEN,(lineX,lineY),(self.maxX,lineY))

      data = self.dataset.get()
      dataLen = len(data)
      xRes = (self.maxX - self.x - self.valueWidth) / dataLen
      pointList = []
      x = lineX
      
      for i in xrange(dataLen):
         y = (self.maxVal - data[i]) * self.yRes + self.y
         pointList.append((x, y))
         x += xRes

      pygame.draw.lines(screen,(0,0,0),False,pointList,1)

class Accelerometer():
   def __init__(self,screen):
      self.screen = screen
      self.box = pygame.image.load("accel.png").convert_alpha()
      self.ball = pygame.image.load("accel_ball.png").convert_alpha()
      self.font = pygame.font.Font("DS-DIGI.TTF",30)

      text = self.font.render("0",True,(0,0,0))
      text1 = self.font.render("1",True,(0,0,0))
      self.oneAdj = (text.get_width() - text1.get_width())/2

      text = self.font.render("-",True,(0,0,0))
      self.negAdj = text.get_width()/2
      
      self.accelX = 0
      self.accelY = 0

      self.datasetX = Dataset(50)
      self.datasetX.setRed(-1.0,1.0)
      self.datasetX.setYellow(-0.5,0.5)

      self.datasetY = Dataset(50)
      self.datasetY.setRed(-1.0,1.0)
      self.datasetY.setYellow(-0.5,0.5)

      self.graphX = Graph(screen,self.datasetX)
      self.graphX.setLocation(320,50,450,140)
      self.graphX.setScale(-1.0,1.0,0)

      self.graphY = Graph(screen,self.datasetY)
      self.graphY.setLocation(320,290,450,140)
      self.graphY.setScale(-1.0,1.0,0)
      
   def setLocation(self,x,y):
      self.x = x
      self.y = y

   def newReading(self,x,y):
      self.accelX = x
      self.datasetX.update(x)
      
      self.accelY = y
      self.datasetY.update(y)
                
   def gaugeRender(self):
      self.screen.blit(self.box, (self.x,self.y))

      # graphic is 182 x 182 pixels, 1G ring is 140 pixels diameter
      
      self.screen.blit(self.ball, (self.x + (self.accelX*70) + 91 - 8,self.y + (self.accelY*70) + 91 - 8))

      text = self.font.render("{:.2f}".format(abs(self.accelX)),True,(0,0,0))
      if self.accelX < 0:
         offset = text.get_width()
         absValue = abs(self.accelX)
         yy = (absValue - math.floor(absValue))
         if yy > 0.05 and yy < 0.15:
            offset += self.oneAdj
         
         self.screen.blit(text,(self.x-7-offset,self.y+75))
      else:
         self.screen.blit(text,(self.x+189,self.y+75))

      text = self.font.render("{:.2f}".format(self.accelY),True,(0,0,0))
      offset = text.get_width()/2
      absValue = abs(self.accelY)
      yy = (absValue - math.floor(absValue))
      if yy > 0.05 and yy < 0.15:
         offset += self.oneAdj

      if self.accelY < 0:
         offset += self.negAdj
         
      self.screen.blit(text,(self.x+91-offset,self.y-30))

   def render(self):
      self.setLocation(341, 280)
      self.gaugeRender();
      
   def renderGraph(self):
      self.setLocation(60,149)
      self.gaugeRender()
      self.graphX.render()  
      self.graphY.render()

class BarGauge():
   def __init__(self,screen,dataset):
      self.screen = screen
      self.dataset = dataset

      self.box = pygame.image.load("bargauge.png").convert_alpha()
      
      self.bigFont = pygame.font.Font("DS-DIGI.TTF",70)
      self.smallFont = pygame.font.Font("DS-DIGI.TTF",30)      

      text0 = self.bigFont.render("0",True,(0,0,0))
      text1 = self.bigFont.render("1",True,(0,0,0))
      self.bigAdj = text0.get_width() - text1.get_width()

      text0 = self.smallFont.render("0",True,(0,0,0))
      text1 = self.smallFont.render("1",True,(0,0,0))
      self.smallAdj = text0.get_width() - text1.get_width()
      
      self.x = 0
      self.y = 0
      self.name = ""

   def setLocation(self,x,y):
      self.x = x 
      self.y = y

   def setScale(self,minVal,maxVal):
      self.maxVal = maxVal
      self.minVal = minVal
      self.yScale = 233.0/ (maxVal - minVal)

   def setName(self,name):
      self.name = name      

   def getColor(self, value):
      return self.dataset.getColor(value)
   
   def render(self):
      value = self.dataset.last()
      if value == None:
         return

         
      color = self.dataset.getColor(value)

      scaleValue = value
      if scaleValue > self.maxVal:
         scaleValue = self.maxVal
      elif scaleValue < self.minVal:
         scaleValue = self.minVal
         
      # draw rects first and cover with graphic later
      top = 2 - (self.yScale * (scaleValue-self.maxVal))
      pygame.draw.rect(self.screen, color, (self.x+142,self.y+top,40,237-top))
      pygame.draw.rect(self.screen, settings.BLACK, (self.x+142,self.y,40,top))

      self.screen.blit(self.box, (self.x,self.y))
      text = self.bigFont.render("{:.1f}".format(value),True,color)
      #text = self.bigFont.render(str(value),True,color)
      offset = text.get_width()

      absValue = abs(value)
      if isinstance(value,float):
         yy = (absValue - math.floor(absValue))
         if yy > 0.05 and yy < 0.15:
	    offset += self.bigAdj
      else:
         if (absValue % 10) == 1:
	    offset += self.bigAdj     
      self.screen.blit(text,(self.x+131-offset,self.y+84))

      xx = self.dataset.min()
      text = self.smallFont.render("{:.1f}".format(xx),True,self.getColor(xx))
      #text = self.smallFont.render(str(xx),True,self.getColor(xx))
      offset = text.get_width()
      absValue = abs(xx)
      if isinstance(xx,float):
         yy = (absValue - math.floor(absValue))
         if yy > 0.05 and yy < 0.15:
	    offset += self.smallAdj
      else:
         if (absValue % 10) == 1:
	    offset += self.smallAdj
      self.screen.blit(text,(self.x+131-offset,self.y+173))

      xx = self.dataset.max()
      text = self.smallFont.render("{:.1f}".format(xx),True,self.getColor(xx))
      #text = self.smallFont.render(str(xx),True,self.getColor(xx))
      offset = text.get_width()
      absValue = abs(xx)
      if isinstance(xx,float):
         yy = (absValue - math.floor(absValue))
         if yy > 0.05 and yy < 0.15:
	    offset += self.smallAdj
      else:
         if (absValue % 10) == 1:
	    offset += self.smallAdj
      self.screen.blit(text,(self.x+131-offset,self.y+35))

      text = self.smallFont.render(self.name,True,(0,0,0))
      self.screen.blit(text,(self.x+0,self.y+0))
     
class LargeBarGauge():
   def __init__(self,screen,dataset):
      self.screen = screen
      self.dataset = dataset

      self.box = pygame.image.load("largeBarGauge.png").convert_alpha()
      
      self.bigFont = pygame.font.Font("DS-DIGI.TTF",86)
      self.smallFont = pygame.font.Font("DS-DIGI.TTF",40)      

      text0 = self.bigFont.render("0",True,(0,0,0))
      text1 = self.bigFont.render("1",True,(0,0,0))
      self.bigAdj = text0.get_width() - text1.get_width()

      text0 = self.smallFont.render("0",True,(0,0,0))
      text1 = self.smallFont.render("1",True,(0,0,0))
      self.smallAdj = text0.get_width() - text1.get_width()
      
      self.x = 0
      self.y = 0
      self.name = ""

   def setLocation(self,x,y):
      self.x = x 
      self.y = y

   def setScale(self,minVal,maxVal):
      self.maxVal = maxVal
      self.minVal = minVal
      self.yScale = 435.0/ (maxVal - minVal)

   def setName(self,name):
      self.name = name      

   def getColor(self, value):
      return self.dataset.getColor(value)
   
   def render(self):
      # current value
      value = self.dataset.last()
      if value == None:
         return
         
      color = self.dataset.getColor(value)

      scaleValue = value
      if scaleValue > self.maxVal:
         scaleValue = self.maxVal
      elif scaleValue < self.minVal:
         scaleValue = self.minVal
         
      # draw rects first and cover with graphic later
      top = 2 - (self.yScale * (scaleValue-self.maxVal))
      pygame.draw.rect(self.screen, color, (self.x+172,self.y+top,53,439-top))
      pygame.draw.rect(self.screen, settings.BLACK, (self.x+172,self.y,53,top))

      self.screen.blit(self.box, (self.x,self.y))
      text = self.bigFont.render("{:.1f}".format(value),True,color)
      #text = self.bigFont.render(str(value),True,color)
      offset = text.get_width()

      absValue = abs(value)
      if isinstance(value,float):
         yy = (absValue - math.floor(absValue))
         if yy > 0.05 and yy < 0.15:
	    offset += self.bigAdj
      else:
         if (absValue % 10) == 1:
	    offset += self.bigAdj     
      self.screen.blit(text,(self.x+160-offset,self.y+175))

      #min value
      xx = self.dataset.min()
      text = self.smallFont.render("{:.1f}".format(xx),True,self.getColor(xx))
      #text = self.smallFont.render(str(xx),True,self.getColor(xx))
      offset = text.get_width()
      absValue = abs(xx)
      if isinstance(xx,float):
         yy = (absValue - math.floor(absValue))
         if yy > 0.05 and yy < 0.15:
	    offset += self.smallAdj
      else:
         if (absValue % 10) == 1:
	    offset += self.smallAdj
      self.screen.blit(text,(self.x+160-offset,self.y+300))

      #max value
      xx = self.dataset.max()
      text = self.smallFont.render("{:.1f}".format(xx),True,self.getColor(xx))
      #text = self.smallFont.render(str(xx),True,self.getColor(xx))
      offset = text.get_width()
      absValue = abs(xx)
      if isinstance(xx,float):
         yy = (absValue - math.floor(absValue))
         if yy > 0.05 and yy < 0.15:
	    offset += self.smallAdj
      else:
         if (absValue % 10) == 1:
	    offset += self.smallAdj
      self.screen.blit(text,(self.x+160-offset,self.y+98))

      text = self.smallFont.render(self.name,True,(0,0,0))
      self.screen.blit(text,(self.x+0,self.y+0))

      
class AfrGauge():
   def __init__(self,screen):
      self.screen = screen

      self.dataset = Dataset(50)
      self.dataset.setRed(12.0,17.0)
      self.dataset.setYellow(13.0,16.0)

      self.gauge = BarGauge(screen,self.dataset)
      self.gauge.setScale(9.0,20.0)
      self.gauge.setName("AFR")

      self.largeGauge = LargeBarGauge(screen,self.dataset)
      self.largeGauge.setScale(9.0,20.0)
      self.largeGauge.setName("AFR")
      
      self.graph = Graph(screen,self.dataset)
      self.graph.setLocation(275,20,560)
      self.graph.setScale(9.0,20.0,14.7)

   def setLocation(self,x,y):
      self.largeGauge.setLocation(x,y)
      self.gauge.setLocation(x+22,y)  

   def newReading(self,value):
      self.dataset.update(value)
      
   def render(self, large=False):
      self.setLocation(30,20)
      
      if large:
         self.largeGauge.render()
      else:
         self.gauge.render()
      
   def renderGraph(self):
      self.setLocation(30,20)
      self.largeGauge.render()
      self.graph.render()

class FuelPressureGauge():
   def __init__(self,screen):
      self.screen = screen

      self.dataset = Dataset(50)
      self.dataset.setRed(30,80)
      self.dataset.setYellow(40,70)

      self.gauge = BarGauge(screen,self.dataset)
      self.gauge.setScale(0,100)
      self.gauge.setName("FP")

      self.largeGauge = LargeBarGauge(screen,self.dataset)
      self.largeGauge.setScale(0,100)
      self.largeGauge.setName("FP")
      
      self.graph = Graph(screen,self.dataset)
      self.graph.setLocation(275,20,560)
      self.graph.setScale(10,100,50)      

   def setLocation(self,x,y):
      self.largeGauge.setLocation(x,y)
      self.gauge.setLocation(x+22,y)  
      
   def newReading(self,value):
      self.dataset.update(value)

   def render(self, large=False):
      self.setLocation(318,20)
      
      if large:
         self.largeGauge.render()
      else:
         self.gauge.render()

   def renderGraph(self):
      self.setLocation(30,20)      
      self.largeGauge.render()
      self.graph.render()
      

class BoostGauge():
   def __init__(self,screen):
      self.screen = screen

      self.dataset = Dataset(50)
      self.dataset.setRed(-15,10)
      self.dataset.setYellow(-13,7)

      self.gauge = BarGauge(screen,self.dataset)
      self.gauge.setScale(-15,15)
      self.gauge.setName("BOOST")

      self.largeGauge = LargeBarGauge(screen,self.dataset)
      self.largeGauge.setScale(-15,15)
      self.largeGauge.setName("BOOST")

      self.graph = Graph(screen,self.dataset)
      self.graph.setLocation(275,20,560)
      self.graph.setScale(-15,15,0)

   def setLocation(self,x,y):
      self.largeGauge.setLocation(x,y)
      self.gauge.setLocation(x+22,y)  
                     
   def newReading(self,value):
      self.dataset.update(value)

   def render(self, large=False):
      self.setLocation(606,20)
      
      if large:
         self.largeGauge.render()
      else:
         self.gauge.render()

   def renderGraph(self):
      self.setLocation(30,20)      
      self.largeGauge.render()
      self.graph.render()
      
class Menu():
   def __init__(self,screen):
      self.screen = screen
      self.font = pygame.font.Font("DS-DIGI.TTF",60)
      self.item = 1
      self.CAL = 1
      self.REBOOT = 2
      self.SHUTDOWN = 3
      self.maxItems = 3
      self.x = 30
      self.y = 30
      self.ySpacing = 75
      
   def firstItem(self):
      self.item = 1

   def nextItem(self):
      self.item += 1
      if self.item > self.maxItems:
         self.item = 1
      
   def prevItem(self):
      self.item -= 1
      if self.item < 1:
         self.item = self.maxItems

   def selectItem(self):
      global menuShown
      global gaugesShown
      global arduinoSerial
      
      if self.item == self.CAL:
         menuShown = False
         gaugesShown = 6
         arduinoSerial.write("cc")
         
      elif self.item == self.REBOOT:
         os.system("sudo shutdown -r now")
      elif self.item == self.SHUTDOWN:
         os.system("sudo shutdown -h now")
      else:
         pass
      
   def render(self):
      x = self.x
      y = self.y
      
      if self.item == self.CAL:
         color = settings.GREEN
      else:
         color = settings.BLACK
         
      text = self.font.render("Calibrate Accelerometer",True,color)
      self.screen.blit(text,(x,y))
      y += self.ySpacing

      if self.item == self.REBOOT:
         color = settings.GREEN
      else:
         color = settings.BLACK
         
      text = self.font.render("Reboot",True,color)
      self.screen.blit(text,(x,y))
      y += self.ySpacing

      if self.item == self.SHUTDOWN:
         color = settings.GREEN
      else:
         color = settings.BLACK
         
      text = self.font.render("Shutdown",True,color)
      self.screen.blit(text,(x,y))
      y += self.ySpacing
      


# airclick wasn't seen by rPi at boot, had to be installed after boot
# unfortunately, not a feasible solution
class AirClick():
   def __init__(self):
      self.PLAY = 250
      self.PREV = 235
      self.NEXT = 243
      self.VOLDOWN = 247
      self.VOLUP = 249

      self.hidfile = open("/dev/usb/hiddev0", "rb+")
      fcntl.fcntl(self.hidfile, fcntl.F_SETFL, os.O_NONBLOCK)

      self.flushNeeded = True
      self.flushTicks = 0
      self.flushBytes = 0

   def __del__(self):
      del(self.hidfile)

   def checkButtonPress(self):
      if self.flushNeeded:
         try:
            x = self.hidfile.read(5000)
            #print "emptied %d" % len(x)
         except:
            x = ''

         #wait at least 500ms before being done flushing, clear flag 
         self.flushBytes += len(x)
         if (pygame.time.get_ticks() - self.flushTicks) >= 200 or self.flushBytes > 500:
            self.flushNeeded = 0
            self.flushBytes = 0
         

      else:
         try:   
            x = self.hidfile.read(5000)
         except:
            x = ''

         if len(x) > 0:
            if self.processButton(x):
               self.flushNeeded = 1
               self.flushTicks = pygame.time.get_ticks()
               
   def processButton(self,x):
      global gaugesShown
      for c in x:
         i = ord(c)

         if i == self.PLAY:
            print "Play"
            return True
         elif i == self.PREV:
            print "Prev"
            gaugesShown -= 1
            if gaugesShown < 0: gaugesShown = 7
            return True
         elif i == self.NEXT:
            print "Next"
            gaugesShown += 1
            if gaugesShown > 7: gaugesShown = 0
            return True
         elif i == self.VOLDOWN:
            print "Vol Down"
            return True
         elif i == self.VOLUP:
            print "Vol Up"
            return True

      return False

def processButton(button):
   global gaugesShown
   global menuShown
   
   if button == 'u':
      if menuShown:
         menu.prevItem()
      else:
         gaugesShown -= 1
         if gaugesShown < 1: gaugesShown = 6
      
   elif button == 'd':
      if menuShown:
         menu.nextItem()
      else:
         gaugesShown += 1
         if gaugesShown > 6: gaugesShown = 1

   elif button == 'l':
      if menuShown:
         menu.prevItem()
      else:
         gaugesShown -= 1
         if gaugesShown < 1: gaugesShown = 6

   elif button == 'r':
      if menuShown:
         menu.nextItem()
      else:
         gaugesShown += 1
         if gaugesShown > 6: gaugesShown = 1

   elif button == 'm':
      menu.firstItem()
      menuShown = not menuShown

   elif button == 's':
      if menuShown:
         menu.selectItem()



# Initialise the app
logging.basicConfig(stream=sys.stderr, level=logging.DEBUG)

pygame.init()
screen = pygame.display.set_mode([0,0])

pygame.mouse.set_visible(False)
pygame.display.set_caption('Gauges')

# Create initial object instances

afrGauge = AfrGauge(screen)
fpGauge = FuelPressureGauge(screen)
accelGauge = Accelerometer(screen)
boostGauge = BoostGauge(screen)

menu = Menu(screen)

#remote = AirClick()

try:
   #Nano
   arduinoSerial = serial.Serial('/dev/ttyUSB0', 115200)
except IOError:
   try:
      #Uno
      arduinoSerial = serial.Serial('/dev/ttyACM0', 115200)
   except IOError:
      print "No Arduino found"
      sys.exit()

   
clock = pygame.time.Clock()


exitGauges = False
xReading = 0.0
yReading = 0.0
gaugesShown = 1
menuShown = False

arduinoSerial.flushInput()
time.sleep(2)
arduinoSerial.flushInput()

# Main loop starts here

while exitGauges != True:
   clock.tick(60) 

# Read sensors and buttons from arduino
   newData = False
   while newData == False or arduinoSerial.inWaiting() > 0:
      fromArd = arduinoSerial.readline()
      newData = True
      if len(fromArd)>0:
         if fromArd[0] == 'a':
            afrGauge.newReading(float(fromArd[1:]))

         elif fromArd[0] == 'f':
            fpGauge.newReading(int(fromArd[1:]))

         # boost psi
         elif fromArd[0] == 'p':
            boostGauge.newReading(float(fromArd[1:]))

         # accelerometer
         elif fromArd[0] == 'x':
            xReading = float(fromArd[1:])
         elif fromArd[0] == 'y':
            yReading = float(fromArd[1:])
            # new Y reading follows x reading in data stream, have them both now
            accelGauge.newReading(xReading, yReading)

         elif fromArd[0] == 'b':
            # buttons
            processButton(fromArd[1])

      
# Set Gauges
      
   screen.fill(settings.WHITE)
   if menuShown:
      menu.render()

   elif gaugesShown == 2:
      afrGauge.render(True)
      fpGauge.render()
      boostGauge.render(True)
      accelGauge.render()
            
   elif gaugesShown == 3:
      afrGauge.renderGraph()

   elif gaugesShown == 4:
      boostGauge.renderGraph()
      
   elif gaugesShown == 5:
      fpGauge.renderGraph()
      
   elif gaugesShown == 6:
      accelGauge.renderGraph()
      
   else:
      gaugesShown = 1
      afrGauge.render(True)
      fpGauge.render(True)
      boostGauge.render(True)
   

# Update the screen
   pygame.display.flip()

# check for button pressed on remote
#   remote.checkButtonPress()


# check for exit
   for event in pygame.event.get():
      if event.type == pygame.QUIT:
         exitGauges = True

      elif event.type == pygame.KEYDOWN:
         if event.key == pygame.K_q:
            exitGauges = True

pygame.image.save(screen, "screenshot.jpg")
pygame.quit()
sys.exit()
